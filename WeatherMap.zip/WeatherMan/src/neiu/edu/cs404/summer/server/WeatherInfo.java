package neiu.edu.cs404.summer.server;

public class WeatherInfo {
	double pres;
	double tmpc;
	double tmwc;
	double dwpc;
	double thte;
	double drct;
	double sknt;
	double omeg;
	double cfrl;
	double hght;

	public double getPres() {
		return pres;
	}

	public void setPres(double pres) {
		this.pres = pres;
	}

	public double getTmpc() {
		return tmpc;
	}

	public void setTmpc(double tmpc) {
		this.tmpc = tmpc;
	}

	public double getTmwc() {
		return tmwc;
	}

	public void setTmwc(double tmwc) {
		this.tmwc = tmwc;
	}

	public double getDwpc() {
		return dwpc;
	}

	public void setDwpc(double dwpc) {
		this.dwpc = dwpc;
	}

	public double getThte() {
		return thte;
	}

	public void setThte(double thte) {
		this.thte = thte;
	}

	public double getDrct() {
		return drct;
	}

	public void setDrct(double drct) {
		this.drct = drct;
	}

	public double getSknt() {
		return sknt;
	}

	public void setSknt(double sknt) {
		this.sknt = sknt;
	}

	public double getOmeg() {
		return omeg;
	}

	public void setOmeg(double omeg) {
		this.omeg = omeg;
	}

	public double getCfrl() {
		return cfrl;
	}

	public void setCfrl(double cfrl) {
		this.cfrl = cfrl;
	}

	public double getHght() {
		return hght;
	}

	public void setHght(double hght) {
		this.hght = hght;
	}

}
